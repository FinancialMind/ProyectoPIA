let iconGast = document.querySelector('.spend__gast');
let logo = document.querySelector('.logo__img');
let icons = document.querySelectorAll('.list__img');
let add = document.querySelector('.btn__add');
let heigth = window.innerHeight;

if(heigth === 767){
    
}


